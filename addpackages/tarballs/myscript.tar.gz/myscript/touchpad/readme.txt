これらのファイルは
https://gist.github.com/zhaostu/4552236
より入手したものに若干の改変を加えたもの。

