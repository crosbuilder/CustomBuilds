script_root=/opt/myscript
script_local=/usr/local/myscript
