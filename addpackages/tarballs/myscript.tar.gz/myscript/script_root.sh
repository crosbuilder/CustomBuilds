script_root=/opt/myscript
script_local=/mnt/stateful_partition/dev_image/myscript


